package com.example.translatetry;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity  {

    private static final String APP_ID = "20200222000387227";
    private static final String SECURITY_KEY = "8PcGcPB0k26PWQS1qWrE";
    private static String ORIGINAL = "";
    private static String SRC = "";
    private static String DST = "";
    private static String LAN="en";
    private SwipeRefreshLayout swipeRefresh;
    private DrawerLayout mDrawerlayout;
    class MyThread extends Thread{
        @Override
        public void run(){
            TransApi api = new TransApi(APP_ID, SECURITY_KEY);
            ORIGINAL=api.getTransResult(SRC, "auto",LAN);

            try {
                JSONObject rootObject = new JSONObject(ORIGINAL);
                JSONArray resultArray = rootObject.getJSONArray("trans_result");
                JSONObject sonObject = resultArray.getJSONObject(0);
                DST=sonObject.getString("dst");
        }
            catch (JSONException e){
                e.printStackTrace();
            }
            Log.d("MainActivity",DST);
            Log.d("MainActivity",SRC);

        }
    }
    public static final int UPDATE_TEXT =1;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case android.R.id.home:
                mDrawerlayout.openDrawer(GravityCompat.START);
                break;
        }
        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);//这句要在最前面
        setContentView(R.layout.activity_main);//这句也一样要在最前面
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        NavigationView navView=(NavigationView)findViewById(R.id.nav_view);
        navView.setCheckedItem(R.id.nav_view);
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.button_uk:
                        LAN="en";
                        break;
                    case R.id.button_jp:
                        LAN="jp";
                        break;
                        default:

                }
                mDrawerlayout.closeDrawers();
                return true;
            }
        });
        mDrawerlayout =(DrawerLayout)findViewById(R.id.drawer_layout);
        ActionBar actionBar=getSupportActionBar();
        if(actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu_manage);
        }
        final SwipeRefreshLayout swipeRefreshLayout;
        swipeRefreshLayout =(SwipeRefreshLayout)findViewById(R.id.swipe_refresh);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                EditText editText;
                editText=(EditText) findViewById(R.id.edit_text);
                SRC =editText.getText().toString();
                TransApi api = new TransApi(APP_ID, SECURITY_KEY);
                new MyThread().start();
                TextView responseText=(TextView) findViewById(R.id.response_text);
                responseText.setText(DST);
                swipeRefreshLayout.setRefreshing(false);
            }
        });
        TransApi api = new TransApi(APP_ID, SECURITY_KEY);
        TextView responseText=(TextView) findViewById(R.id.response_text);

    }
}
